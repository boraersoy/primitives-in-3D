import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
import numpy as np
from Camera import Camera
class Object3D:
    def __init__(self):
        self.original_vertices = [] #store this in order to undo operation 
        self.transformation_stack = []
        self.transformation_order = []
        self.transformed_vertices = []

    def add_vertex(self,vertex):
        self.original_vertices.append(vertex)
        self.transformed_vertices.append(vertex)

    def push_transformation(self,matrix,order):
        self.transformation_stack.append((matrix,order))
        self.transformation_order.append(order)

    def pop_transformation(self):
        if self.transformation_stack:
            self.transformation_stack.pop()
            self.transformation_order.pop()

    def apply_transformations(self):
        if not self.transformation_stack:
            return "nothing left in transformation stack"

        product_matrix = np.identity(4, dtype = np.float32)
        for matrix,order in self.transformation_stack:
            if order:
                product_matrix = np.dot(product_matrix,matrix.data)

        for i in range(len(self.transformed_vertices)):
            self.transformed_vertices[i] = product_matrix @ self.original_vertices[i].data


                
    def get_transformation_order(self):
        return self.transformation_order


    def clear(self):
        self.transformation_order.clear()
        self.transformation_stack.clear()
        self.transformed_vertices = self.original_vertices.copy()



    def rotate_object(self,rtri,x,y,z):
        if x == 1:
            rotation_matrix = Mat3D.rotation_x(np.radians(rtri))
            self.push_transformation(rotation_matrix, "RX")

        if y ==1:
            rotation_matrix = Mat3D.rotation_y(np.radians(rtri))
            self.push_transformation(rotation_matrix, "RY")

        if z ==1:
            rotation_matrix = Mat3D.rotation_z(np.radians(rtri))
            self.push_transformation(rotation_matrix, "RZ")


        self.apply_transformations()
    
    def translate(self,x,y,z):

        translation_vector = Vec3D(x, y,z)
        translation_matrix = Mat3D.translation(translation_vector)
        self.push_transformation(translation_matrix,"T")
        self.apply_transformations()
    
    def scale(self,x,y,z):
        translation_vector = Vec3D(x, y,z)
        translation_matrix = Mat3D.scaling(translation_vector.x, translation_vector.y, translation_vector.z)
        self.push_transformation(translation_matrix,"S")
        self.apply_transformations()

    def perspective_projection(self,aspect_ratio):
        FOV  = 90.0
        tanHalfFOV = np.tan(np.deg2rad(FOV / 2.0))
        f = 1 / tanHalfFOV
        translation_matrix = Mat3D.projection(f,aspect_ratio)
        self.push_transformation(translation_matrix,"P")
        self.apply_transformations()
    
