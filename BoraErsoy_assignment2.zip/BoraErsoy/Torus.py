import math
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import math
from Object3D import Object3D
import numpy as np
from Vec3D import Vec3D
class Torus(Object3D):
    def __init__(self, radius_major, radius_minor, sector_count, stack_count):
        super().__init__()
        
        self.radius_major = radius_major
        self.radius_minor = radius_minor
        self.sector_count = sector_count
        self.stack_count = stack_count
        self.indices = []
        self.normals = []
        self.tex_coords = []
        self.vertices = []

    def generate_torus(self):
        for i in range(self.stack_count + 1):
            stack_angle = math.pi * (-0.5 + float(i) / self.stack_count)
            stack_radius = math.cos(stack_angle)
            stack_y = math.sin(stack_angle)

            for j in range(self.sector_count + 1):
                sector_angle = 2 * math.pi * float(j) / self.sector_count
                sector_x = stack_radius * math.cos(sector_angle)
                sector_z = stack_radius * math.sin(sector_angle)

                x = sector_x * self.radius_major
                y = stack_y * self.radius_minor
                z = sector_z * self.radius_major

                nx = sector_x
                ny = stack_y
                nz = sector_z

                u = float(j) / self.sector_count
                v = float(i) / self.stack_count
                vector = Vec3D(x,y,z)
                self.add_vertex(vector)
                self.vertices.extend([x, y, z])
                self.normals.extend([nx, ny, nz])
                self.tex_coords.extend([u, v])

        for i in range(self.stack_count):
            k1 = i * (self.sector_count + 1)
            k2 = k1 + self.sector_count + 1

            for j in range(self.sector_count):
                if i != 0:
                    self.indices.extend([k1, k2, k1 + 1])
                if i != (self.stack_count - 1):
                    self.indices.extend([k1 + 1, k2, k2 + 1])

                k1 += 1
                k2 += 1
    def draw_torus(self):
        glBegin(GL_TRIANGLES)
        
        for i in range(len(self.transformed_vertices)):
            glVertex3f(self.transformed_vertices[self.indices[i]][0], self.transformed_vertices[self.indices[i]][1], self.transformed_vertices[self.indices[i]][2])


        glEnd()

# Example usage:
radius_major = 3.0
radius_minor = 1.0
sector_count = 36
stack_count = 18

torus = Torus(radius_major, radius_minor, sector_count, stack_count)
torus.generate_torus()

# Access the result:
