# CENG487 Introduction To Computer Graphics
# Development Env Test Program
# Runs in python 3.x env
# with PyOpenGL and PyOpenGL-accelerate packages
#display of the object looks very awful now and some objects have missing parts i ll update my code and reupload again
#it looks kinda sloppy now i ll try to improve  
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Cylinder import Cylinder
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D
import numpy as np
from triangle import Triangle
from Quad import Quad
from cube import Cube
from pyramid import Pyramid
from Sphere import Sphere
from Torus import Torus
from Camera import Camera
# Number of the glut window.
window = 0
sector = 18
stack = 36
# Rotation angle for the triangle.
rtri = 0
# Rotation angle for the quadrilateral.
rquad = 0.0



q1 = Vec3D(-1,1,0)
q2 = Vec3D(1,1,0)
q3 = Vec3D(1,-1,0)
q4 = Vec3D(-1,-1,0)
quad = Quad()

quad.add_vertex(q1)
quad.add_vertex(q2)
quad.add_vertex(q3)
quad.add_vertex(q4)
quad.translate(-8.5,-5.0,-6.0)
quad.scale(15,50,50)

cube = Cube()
cube = cube.create_cube()
cube.translate(-8.5, 0.0, -6.0)


pyramid = Pyramid()
pyramid = pyramid.create_pyramid()
pyramid.translate(-4.5, 0.0, -6.0)



radius = 1.0
height = 2.0
sector_count = 15

cylinder = Cylinder(radius, height, sector_count)
cylinder.build_vertices_smooth()
cylinder.generate_cylinder_indices()
cylinder.translate(1.5, 0.0, -6.0)
radius_major = 3.0
radius_minor = 1.0
sector_count = 36
stack_count = 18

# torus = Torus(radius_major, radius_minor, sector_count, stack_count)
# torus.generate_torus()
# torus.translate(1.5,0.0,-6.0)
sphere = Sphere(1,sector,stack)

sphere.calculate_vertices_normals_texture_coordinates()
sphere.calculate_triangles()
sphere.translate(5.5,0.0, -6)

camera = Camera()





# A general OpenGL initialization function.  Sets all of the initial parameters.
def InitGL(Width, Height):				# We call this right after our OpenGL window is created.
	glClearColor(0.0, 0.0, 0.0, 0.0)	# This Will Clear The Background Color To Black
	glClearDepth(1.0)					# Enables Clearing Of The Depth Buffer
	glDepthFunc(GL_LESS)				# The Type Of Depth Test To Do
	glEnable(GL_DEPTH_TEST)				# Enables Depth Testing
	glShadeModel(GL_SMOOTH)				# Enables Smooth Color Shading

	glMatrixMode(GL_PROJECTION)
	glLoadIdentity()					# Reset The Projection Matrix
										# Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0, float(Width)/float(Height), 0.1, 100.0)

	glMatrixMode(GL_MODELVIEW)


# The function called when our window is resized (which shouldn't happen if you enable fullscreen, below)
def ReSizeGLScene(Width, Height):
	if Height == 0:						# Prevent A Divide By Zero If The Window Is Too Small
		Height = 1

	glViewport(0, 0, Width, Height)		# Reset The Current Viewport And Perspective Transformation
	glMatrixMode(GL_PROJECTION)
	glLoadIdentity()
	gluPerspective(45.0, float(Width)/float(Height), 0.1, 100.0)
	glMatrixMode(GL_MODELVIEW)


# The main drawing function.
def DrawGLScene():
	global rtri, triangle, cube, quad, pyramid,sphere,sector, stack,camera 


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	# Clear The Screen And The Depth Buffer
	glLoadIdentity();				# Reset The View
	gluLookAt(camera.m_pos.x,camera.m_pos.y, camera.m_pos.z,
	(camera.m_pos + camera.m_target).x, (camera.m_pos + camera.m_target).y, (camera.m_pos + camera.m_target).z,
	camera.m_up.x, camera.m_up.y, camera.m_up.z		 )


	cube.rotate_object(rtri, 1,1,1)
	cube.draw_box()


	pyramid.rotate_object(rtri, 1,1,1)
	pyramid.draw_pyramid()
	
	# quad.draw_quad()
	
	sphere = Sphere(1,sector,stack)

	sphere.calculate_vertices_normals_texture_coordinates()
	sphere.calculate_triangles()
	sphere.translate(5.5,0.0, -6)
	sphere.rotate_object(rtri, 1,1,1)

	sphere.draw_sphere()
	cylinder = Cylinder(radius, height, sector)
	cylinder.build_vertices_smooth()
	cylinder.generate_cylinder_indices()
	cylinder.translate(1.5, 0.0, -6.0)
	cylinder.rotate_object(rtri, 1,1,1)
	cylinder.draw_cylinder()
	cylinder.draw_cirles()
	
	
		# quad.rotate_object(rtri)
	#quad.draw_quad()
	# torus.rotate_object(rtri, 1,1,1)
	# torus.draw_torus()
	glutSwapBuffers()


# The function called whenever a key is pressed. Note the use of Python tuples to pass in: (key, x, y)
def keyPressed(key, x, y):


	# If escape is pressed, kill everything.
	# ord() is needed to get the keycode
	global rtri, triangle,stack, sector,camera 
	if ord(key) == 27:
		# Escape key = 27Aw
		glutLeaveMainLoop()
		return
	if key == b'W':
		camera.m_pos = camera.m_pos.__add__(camera.m_target.scale(camera.m_speed)) #(camera.m_target * camera.m_speed)
		print(camera.m_pos)

	elif key == b'S':
		camera.m_pos = camera.m_pos.__sub__(camera.m_target.scale(camera.m_speed))
		print(camera.m_pos)

	elif key == b'A':
		left = camera.m_target.cross(camera.m_up)
		left.normalize()
		left.scale(camera.m_speed)
		camera.m_pos = camera.m_pos.__add__(left)
		print(camera.m_pos)

	elif key == b'D':
		right = camera.m_up.cross(camera.m_target)
		right.normalize()
		right.scale(camera.m_speed)
		camera.m_pos = camera.m_pos.__add__(right)
		print(camera.m_pos)

	elif key == b'E':
		camera.m_pos.y += camera.m_speed
		print(camera.m_pos)

	elif key == b'q':
		camera.m_pos.y -= camera.m_speed
		print(camera.m_pos)

	elif key == b'+':
		camera.m_speed += 0.1
		print(f"Speed changed to {camera.m_speed}")

	elif key == b'-':
		camera.m_speed -= 0.1
		if camera.m_speed < 0.1:
			camera.m_speed = 0.1
		print(f"Speed changed to {camera.m_speed}")

	if ord(key) == 97:
		rtri += 0.1
		print(rtri)
	if ord(key) == 100:
		rtri -= 0.1

	if ord(key) == 81: #Q
		stack +=1
		print(stack)
	if ord(key) == 82: #R
		stack -= 1
		print(stack)
	if ord(key) == 84: #T
		sector += 1
		print(sector)
	if(ord(key) == 85): #U
		sector -= 1
		print(sector)


def main():
	global window
	glutInit(sys.argv)

	# Select type of Display mode:
	#  Double buffer
	#  RGBA color
	#  Alpha components supported
	#  Depth buffer
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)

	# get a 640 x 480 window
	glutInitWindowSize(640, 480)

	# the window starts at the upper left corner of the screen
	glutInitWindowPosition(0, 0)

	# Okay, like the C version we retain the window id to use when closing, but for those of you new
	# to Python (like camera), remember this assignment would make the variable local and not global
	# if it weren't for the global declaration at the start of main.
	window = glutCreateWindow("CENG487 Development Env Test")

   	# Register the drawing function with glut, BUT in Python land, at least using PyOpenGL, we need to
	# set the function pointer and invoke a function to actually register the callback, otherwise it
	# would be very much like the C version of the code.
	glutDisplayFunc(DrawGLScene)

	# Uncomment this line to get full screen.
	# glutFullScreen()

	# When we are doing nothing, redraw the scene.
	glutIdleFunc(DrawGLScene)

	# Register the function called when our window is resized.
	glutReshapeFunc(ReSizeGLScene)

	# Register the function called when the keyboard is pressed.
	glutKeyboardFunc(keyPressed)

	# Initialize our window.
	InitGL(640, 480)

	# Start Event Processing Engine
	glutMainLoop()

# Print message to console, and kick off the main to get it rolling.
print ("Hit ESC key to quit.")
print("a to increase rotation speed")
print("s to print object vertices")
print("d to decrease rotation speed")
print("press W to zoom in ")
print("press D to move left")
print("press A to move right")
print("press S to zoom out")
print("press q to move up")
print("press E to move down ")
print("care caps-lock pls :)")
print("press Q to increase number of stacks of sphere and cylinder")
print("press T to increase number of sectors  of sphere and cylinder")
print("press R to decrease number of stacks of sphere and cylinder")
print("press U to decrease number of stacks of sphere and cylinder")

main()