import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D
import numpy as np
pi = np.pi
np.random.seed(32)
class Sphere(Object3D):

    def __init__(self,radius,sectorCount,stackCount):
        super().__init__()
        self.sphere = Object3D()
        self.radius = radius
        self.sectorCount = sectorCount
        self.stackCount = stackCount
        self.normals = []
        self.texCoords = []
        self.indices = []
        self.lineIndices = []
            
    @staticmethod
    def calculate_vertice(r, alpha, sigma):
        alpha = np.deg2rad(alpha)
        sigma = np.deg2rad(sigma)
        x = r * np.cos(alpha) * np.cos(sigma)
        y = r * np.cos(alpha) * np.sin(sigma)
        z = r * np.sin(sigma)
        return Vec3D(x,y,z)


    def draw_sphere(self):
        glBegin(GL_TRIANGLES)
        
        for i in range(len(self.indices)):
            index = self.indices[i]
            if index < (len(self.transformed_vertices)):
                
            
                glColor3f(1.0,0.0,1.0)
                
                glVertex3f(self.transformed_vertices[index][0],self.transformed_vertices[index][1],self.transformed_vertices[index][2]);


        # for i in range(len(self.transformed_vertices)):
        #     glVertex3f(self.transformed_vertices[i][0],self.transformed_vertices[i][1],self.transformed_vertices[i][2]);

        glEnd()
    
    def setRadius(self, radius):
        self.radius = radius
    
    def setSectorCount(self,count):
        self.sectorCount = count

    def setStackCount(self,count):
        self.stackCount = count
        
    def calculate_vertices_normals_texture_coordinates(self):
        x,y,z,xy = 0,0,0,0
        nx, ny, nz = 0,0,0 
        lenghtInv = 1.0 / self.radius
        s,t = 0,0
        sectorStep = 2 * pi / self.sectorCount
        stackStep = pi / self.stackCount
        sectorAngle, stackAngle = 0,0

        for i in range(self.stackCount):
            stackAngle = pi /2 - i * stackStep
            xy = self.radius * np.cos(stackAngle)
            z = self.radius * np.sin(stackAngle)


            for j in range(self.sectorCount):

                sectorAngle = j * sectorStep

                x = xy * np.cos(sectorAngle)
                y  =xy * np.sin(sectorAngle)
                vector = Vec3D(x,y,z)
                self.add_vertex(vector)

                nx = x * lenghtInv
                ny = y * lenghtInv
                nz = z * lenghtInv
                normal = Vec3D(nx,ny,nz)
                self.normals.append(normal)

                s = j / self.sectorCount
                t = i /self.stackCount
                self.texCoords.append(s)
                self.texCoords.append(t)



    def calculate_triangles(self):
        k1, k2 = 0,0
        
        for i in range(self.stackCount):
            k1 = i * (self.sectorCount + 1)
            k2 = k1 + self.sectorCount + 1
            
            for j in range(self.sectorCount):

                if i != 0:
                    self.indices.append(k1)
                    self.indices.append(k2)
                    self.indices.append(k1 + 1)

                if i != self.stackCount -1:
                    self.indices.append(k1 + 1)
                    self.indices.append(k2)
                    self.indices.append(k2 + 1)

                self.lineIndices.append(k1);
                self.lineIndices.append(k2);
                if i != 0:
                    self.lineIndices.append(k1)
                    self.lineIndices.append(k1 + 1)
                
                k1+=1
                k2+=1


 








