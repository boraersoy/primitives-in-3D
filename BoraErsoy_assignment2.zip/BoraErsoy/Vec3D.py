import math
import numpy as np
class Vec3D:
    def __init__(self,x,y,z,w = 1.0):
        self.x = x
        self.y = y
        self.z = z
        self.w = w
        self.data = np.array([x,y,z,w],dtype=np.float32)
        
    def __add__(self,other):
        return Vec3D(self.x + other.x, self.y + other.y,
            self.z + other.z)
    def __sub__(self,other):
        return Vec3D(self.x - other.x, self.y -other.y, self.z - other.z)

    def dot(self,other):
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other):
        return Vec3D(self.y * other.z - self.z * other.y,
                     self.z * other.x - self.x * other.z,
                     self.x * other.y - self.y * other.x)
    def scale(self,scalar):
        return Vec3D(self.x * scalar, self.y * scalar, self.z * scalar)

    def magnitude(self):
        return math.sqrt(self.x ** 2 + self.y **2 + self.z **2)
    def normalize(self):
        mag = self.magnitude()
        return Vec3D(self.x / mag, self.y / mag, self.z / mag)
    
    def angle(self, other):
        cos_theta = self.dot(other) / (self.length() * other.length())
        return math.acos(cos_theta)

    def projection_to(self, basis):
        dot = self.dot(basis)
        basis_length = basis.length()
        return basis * (dot / (basis_length * basis_length))

    def __str__(self):
        return f"({self.x}, {self.y}, {self.z})"




    