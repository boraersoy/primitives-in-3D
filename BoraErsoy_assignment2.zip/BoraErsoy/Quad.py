import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D
import numpy as np

class Quad(Object3D):

    def __init__(self):
        super().__init__()
        self.quad = Object3D()
    

    def draw_quad(self):
            
        glBegin(GL_QUADS);
        glColor3f(1.0,1.0,1.0);			# Set The Color To Blue
			# Start Drawing The Pyramid
        glVertex3f(self.transformed_vertices[0][0],self.transformed_vertices[0][1],self.transformed_vertices[0][2]);
        glVertex3f(self.transformed_vertices[1][0],self.transformed_vertices[1][1],self.transformed_vertices[1][2]);
        glVertex3f(self.transformed_vertices[2][0],self.transformed_vertices[2][1],self.transformed_vertices[2][2]);
        glVertex3f(self.transformed_vertices[3][0],self.transformed_vertices[3][1],self.transformed_vertices[3][2]);
       
        glEnd();
        