import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D
import numpy as np

class Pyramid(Object3D):

    def __init__(self):
        super().__init__()
        self.pyramid = Object3D()
    

    def draw_pyramid(self):
            
        glBegin(GL_TRIANGLES);

        for i in range(12):
            if i == 0:			# Start Drawing The Pyramid
                glColor3f(0.0,1.0,0.0);			# Set The Color To Blue
            elif i == 4:
                glColor3f(1.0,1.0,0.0);			# Set The Color To Blue
            elif i == 8:
                glColor3f(0.0,1.0,1.0);			# Set The Color To Blue
            elif i == 12:
                glColor3f(1.0,1.0,1.0);

            glVertex3f(self.transformed_vertices[i][0],self.transformed_vertices[i][1],self.transformed_vertices[i][2]);


        glEnd();
    
    def create_pyramid(self):
        pyramid = Pyramid()

        pyramid1 =   Vec3D( 0.0, 1.0, 0.0);		# Top Of Triangle (Front)
        pyramid2 =   Vec3D(-1.0,-1.0, 1.0);		# Left Of Triangle (Front)
        pyramid3 =   Vec3D( 1.0,-1.0, 1.0);

        pyramid4 =   Vec3D( 0.0, 1.0, 0.0);		# Top Of Triangle (Right)
        pyramid5 =   Vec3D( 1.0,-1.0, 1.0);		# Left Of Triangle (Right)
        pyramid6 =   Vec3D( 1.0,-1.0, -1.0);	# Right

        pyramid7 =   Vec3D( 0.0, 1.0, 0.0);		# Top Of Triangle (Back)
        pyramid8 =   Vec3D( 1.0,-1.0, -1.0);	# Left Of Triangle (Back)
        pyramid9 =   Vec3D(-1.0,-1.0, -1.0);	# Right Of


        pyramid10 =   Vec3D( 0.0, 1.0, 0.0);		# Top Of Triangle (Left)
        pyramid11 =  Vec3D(-1.0,-1.0,-1.0);		# Left Of Triangle (Left)
        pyramid12 =  Vec3D(-1.0,-1.0, 1.0);		# Right Of Triangle (Left)
        pyramid.add_vertex(pyramid1)
        pyramid.add_vertex(pyramid2)
        pyramid.add_vertex(pyramid3)
        pyramid.add_vertex(pyramid4)
        pyramid.add_vertex(pyramid5)
        pyramid.add_vertex(pyramid6)
        pyramid.add_vertex(pyramid7)
        pyramid.add_vertex(pyramid8)
        pyramid.add_vertex(pyramid9)
        pyramid.add_vertex(pyramid10)
        pyramid.add_vertex(pyramid11)
        pyramid.add_vertex(pyramid12)
 
        return pyramid



