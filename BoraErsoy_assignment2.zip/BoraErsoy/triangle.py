import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D
import numpy as np

class Triangle(Object3D):

    def __init__(self):
        super().__init__()
        self.triangle = Object3D()
    


    def draw_triangle(self):
            
        glBegin(GL_TRIANGLES);			# Start Drawing The Pyramid
        glVertex3f(self.transformed_vertices[0][0],self.transformed_vertices[0][1],self.transformed_vertices[0][2]);
        glVertex3f(self.transformed_vertices[1][0],self.transformed_vertices[1][1],self.transformed_vertices[1][2]);
        glVertex3f(self.transformed_vertices[2][0],self.transformed_vertices[2][1],self.transformed_vertices[2][2]);
        glEnd();
    
    def return_triangle_modern(self):
        all_vertices = []
        for i in range(3):
            all_vertices.append(self.transformed_vertices[i][0])
            all_vertices.append(self.transformed_vertices[i][1])
            all_vertices.append(self.transformed_vertices[i][2])
            all_vertices.append(self.transformed_vertices[i][3])


        all_vertices  = np.array(all_vertices,dtype = "float32")

        return all_vertices