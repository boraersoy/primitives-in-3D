
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D

class Camera:
    def __init__(self):
        self.m_pos = Vec3D(0.0, 0.0, -30.0)
        self.m_target = Vec3D(0.0, 0.0, 1.0)
        self.m_up = Vec3D(0.0, 1.0, 0.0)
        self.m_speed = 0.1

    def set_position(self, x, y, z):
        self.m_pos = Vec3D(x, y, z)

    def get_matrix(self):
        camera_transform = Mat3D.create_look_at(self.m_pos, self.m_pos + self.m_target, self.m_up)
        return camera_transform
    def on_keyboard(self, key):
        print(key)
        if key == b' ':  # Space key
            return 0
        if key == b'W':
            self.m_pos = self.m_pos.__add__(self.m_target.scale(self.m_speed)) #(self.m_target * self.m_speed)
            print(self.m_pos)

        elif key == b'S':
            self.m_pos = self.m_pos.__sub__(self.m_target.scale(self.m_speed))
            print(self.m_pos)

        elif key == b'A':
            left = self.m_target.cross(self.m_up)
            left.normalize()
            left.scale(self.m_speed)
            self.m_pos = self.m_pos.__add__(left)
            print(self.m_pos)

        elif key == b'D':
            right = self.m_up.cross(self.m_target)
            right.normalize()
            right.scale(self.m_speed)
            self.m_pos = self.m_pos.__add__(right)
            print(self.m_pos)

        elif key == b'E':
            self.m_pos.y += self.m_speed
            print(self.m_pos)

        elif key == b'q':
            self.m_pos.y -= self.m_speed
            print(self.m_pos)

        elif key == b'+':
            self.m_speed += 0.1
            print(f"Speed changed to {self.m_speed}")

        elif key == b'-':
            self.m_speed -= 0.1
            if self.m_speed < 0.1:
                self.m_speed = 0.1
            print(f"Speed changed to {self.m_speed}")
#World Matrix is translation * rotation

#WVP is projection * camera * world
