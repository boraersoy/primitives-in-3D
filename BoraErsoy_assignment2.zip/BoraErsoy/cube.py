import numpy as np
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import sys
from Mat3D import Mat3D
from Vec3D import Vec3D
from Object3D import Object3D


class Cube(Object3D):

    def __init__(self):
        super().__init__()
        self.cube = Object3D()
    

    def draw_box(self):
            
        glBegin(GL_QUADS);

        for i in range(20):
            if i == 0:			# Start Drawing The Pyramid
                glColor3f(0.0,1.0,0.0);			# Set The Color To Blue
            elif i == 4:
                glColor3f(1.0,1.0,0.0);			# Set The Color To Blue
            elif i == 8:
                glColor3f(0.0,1.0,1.0);			# Set The Color To Blue
            elif i == 12:
                glColor3f(1.0,1.0,0.5);
            elif i == 16:
                glColor3f(1.0,0.0,0.0);
            elif i == 20:
                glColor3f(0.0,0.0,1.0);			# Set The Color To Blue			# Set The Color To Blue			# Set The Color To Blue
            glVertex3f(self.transformed_vertices[i][0],self.transformed_vertices[i][1],self.transformed_vertices[i][2]);


        glEnd();
    
    def create_cube(self):
        cube = Cube()
        # quad1 = Vec3D( 1.0, 1.0,-1.0);		# Top Right Of The Quad (Top)
        # quad2 = Vec3D(-1.0, 1.0,-1.0);		# Top Left Of The Quad (Top)
        # quad3 = Vec3D(-1.0, 1.0, 1.0);		# Bottom Left Of The Quad (Top)
        # quad4 = Vec3D( 1.0, 1.0, 1.0);		# Bottom Right Of The Quad (Top)

        quad5 = Vec3D( 1.0,-1.0, 1.0);		# Top Right Of The Quad (Bottom)
        quad6 = Vec3D(-1.0,-1.0, 1.0);		# Top Left Of The Quad (Bottom)
        quad7 = Vec3D(-1.0,-1.0,-1.0);		# Bottom Left Of The Quad (Bottom)
        quad8 = Vec3D( 1.0,-1.0,-1.0);		# Bottom Right Of The Quad (Bottom)

                    # Set The Color To Red
        quad9 = Vec3D( 1.0, 1.0, 1.0);		# Top Right Of The Quad (Front)
        quad11 = Vec3D(-1.0, 1.0, 1.0);		# Top Left Of The Quad (Front)
        quad12 = Vec3D(-1.0,-1.0, 1.0);		# Bottom Left Of The Quad (Front)
        quad13 = Vec3D( 1.0,-1.0, 1.0);		# Bottom Right Of The Quad (Front)

        quad14 = Vec3D( 1.0,-1.0,-1.0);		# Bottom Left Of The Quad (Back)
        quad15 = Vec3D(-1.0,-1.0,-1.0);		# Bottom Right Of The Quad (Back)
        quad16 = Vec3D(-1.0, 1.0,-1.0);		# Top Right Of The Quad (Back)
        quad17 = Vec3D( 1.0, 1.0,-1.0);		# Top Left Of The Quad (Back)

        quad18 = Vec3D(-1.0, 1.0, 1.0);		# Top Right Of The Quad (Left)
        quad19 = Vec3D(-1.0, 1.0,-1.0);		# Top Left Of The Quad (Left)
        quad20 = Vec3D(-1.0,-1.0,-1.0);		# Bottom Left Of The Quad (Left)
        quad21 =Vec3D(-1.0,-1.0, 1.0);		# Bottom Right Of The Quad (Left)

        quad22 = Vec3D( 1.0, 1.0,-1.0);		# Top Right Of The Quad (Right)
        quad23 = Vec3D( 1.0, 1.0, 1.0);		# Top Left Of The Quad (Right)
        quad24 = Vec3D( 1.0,-1.0, 1.0);		# Bottom Left Of The Quad (Right)
        quad25 = Vec3D( 1.0,-1.0,-1.0);		# Bottom Right Of The Quad (Right)
        # cube.add_vertex(quad1)
        # cube.add_vertex(quad2)
        # cube.add_vertex(quad3)
        # cube.add_vertex(quad4)
        cube.add_vertex(quad5)
        cube.add_vertex(quad6)
        cube.add_vertex(quad7)
        cube.add_vertex(quad8)
        cube.add_vertex(quad9)
        cube.add_vertex(quad11)
        cube.add_vertex(quad12)
        cube.add_vertex(quad13)
        cube.add_vertex(quad14)
        cube.add_vertex(quad15)
        cube.add_vertex(quad16)
        cube.add_vertex(quad17)
        cube.add_vertex(quad18)
        cube.add_vertex(quad19)
        cube.add_vertex(quad20)
        cube.add_vertex(quad21)
        cube.add_vertex(quad22)
        cube.add_vertex(quad23)
        cube.add_vertex(quad24)
        cube.add_vertex(quad25)
        return cube