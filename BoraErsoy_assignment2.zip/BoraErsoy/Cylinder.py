from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import math
from Object3D import Object3D
import numpy as np

from Vec3D import Vec3D
class Cylinder(Object3D):
    def __init__(self, radius, height, sector_count):
        super().__init__()

        self.radius = radius
        self.height = height
        self.sector_count = sector_count
        self.vertices = []
        self.normals = []
        self.tex_coords = []
        self.base_center_index = 0
        self.top_center_index = 0
        self.indices = []

        

    def get_unit_circle_vertices(self):
        PI = 3.1415926
        sectorStep = 2 * PI / self.sector_count
        unitCircleVertices = []

        for i in range(self.sector_count + 1):
            sectorAngle = i * sectorStep
            unitCircleVertices.extend([math.cos(sectorAngle), math.sin(sectorAngle), 0])

        return unitCircleVertices

    def build_vertices_smooth(self):
        self.vertices.clear()
        self.normals.clear()
        self.tex_coords.clear()

        unitVertices = self.get_unit_circle_vertices()

        for i in range(2):
            h = -self.height / 2.0 + i * self.height
            t = 1.0 - i

            for j in range(self.sector_count + 1):
                k = j * 3
                ux, uy, uz = unitVertices[k], unitVertices[k + 1], unitVertices[k + 2]
                vector = Vec3D(ux * self.radius, uy * self.radius, h)
                self.add_vertex(vector)

                self.vertices.extend([ux * self.radius, uy * self.radius, h])
                self.normals.extend([ux, uy, uz])
                self.tex_coords.extend([float(j) / self.sector_count, t])

        self.base_center_index = len(self.vertices) // 3
        self.top_center_index = self.base_center_index + self.sector_count + 1

        for i in range(2):
            h = -self.height / 2.0 + i * self.height
            nz = -1 + i * 2
            vector = Vec3D(0,0,h)
            self.add_vertex(vector)
            self.vertices.extend([0, 0, h])
            self.normals.extend([0, 0, nz])
            self.tex_coords.extend([0.5, 0.5])

            for j in range(self.sector_count):
                k = j * 3
                ux, uy = unitVertices[k], unitVertices[k + 1]
                vector = Vec3D(ux * self.radius, uy * self.radius, h)
                self.add_vertex(vector)
                self.vertices.extend([ux * self.radius, uy * self.radius, h])
                self.normals.extend([0, 0, nz])
                self.tex_coords.extend([-ux * 0.5 + 0.5, -uy * 0.5 + 0.5])


    def draw_cylinder(self):
        glBegin(GL_TRIANGLES)
        glColor3f(1.0,1.0,0.0)
        for i in range(len(self.transformed_vertices)):
            glVertex3f(self.transformed_vertices[self.indices[i]][0], self.transformed_vertices[self.indices[i]][1], self.transformed_vertices[self.indices[i]][2])


        glEnd()
    
    def draw_cirles(self):
        glBegin(GL_TRIANGLE_FAN)
        for i in range(len(self.transformed_vertices)):
            if(74 or 111 in self.transformed_vertices[i]):
                glColor3f(0.0,0.5,0.3)
                glVertex3f(self.transformed_vertices[self.indices[i]][0], self.transformed_vertices[self.indices[i]][1], self.transformed_vertices[self.indices[i]][2])
        glEnd()

    def generate_cylinder_indices(self):

        k1 = 0  # 1st vertex index at base
        k2 = self.sector_count + 1  # 1st vertex index at top

        # indices for the side surface
        for i in range(self.sector_count):
            # 2 triangles per sector
            # k1 => k1+1 => k2
            self.indices.extend([k1, k1 + 1, k2])

            # k2 => k1+1 => k2+1
            self.indices.extend([k2, k1 + 1, k2 + 1])

            k1 += 1
            k2 += 1

        # indices for the base surface
        k = self.base_center_index + 1
        for i in range(sector_count):
            if i < sector_count - 1:
                self.indices.extend([self.base_center_index, k + 1, k])
            else:  # last triangle
                self.indices.extend([self.base_center_index, self.base_center_index + 1, k])
            k += 1

        # indices for the top surface
        k = self.top_center_index + 1
        for i in range(sector_count):
            if i < sector_count - 1:
                self.indices.extend([self.top_center_index, k, k + 1])
            else:  # last triangle
                self.indices.extend([self.top_center_index, k, self.top_center_index + 1])
            k += 1

radius = 1.0
height = 2.0
sector_count = 36

cylinder = Cylinder(radius, height, sector_count)
cylinder.build_vertices_smooth()
cylinder.generate_cylinder_indices()


