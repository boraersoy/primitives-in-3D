#functions to implement are identity translation rotation around axises scaling transpose mul inverse
import numpy as np
class Mat3D:
    def __init__(self,data):
        self.data = np.array(data) #data must be numpy array type

    @staticmethod
    def identity():
        return Mat3D(np.identity(4))

    @staticmethod
    def translation(translation_vector):
        tx = translation_vector.x
        ty = translation_vector.y
        tz = translation_vector.z
        return Mat3D([[1,0,0,tx],
                      [0,1,0,ty],
                      [0,0,1,tz],
                      [0,0,0,1]])
    

    @staticmethod
    def scaling(sx, sy, sz):
        return Mat3D([[sx, 0, 0, 0],
                      [0, sy, 0, 0],
                      [0, 0, sz, 0],
                      [0, 0, 0, 1]])

    
    @staticmethod
    def rotation_x(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[1, 0, 0, 0],
                      [0, cos_theta, -sin_theta, 0],
                      [0, sin_theta, cos_theta, 0],
                      [0, 0, 0, 1]])

    @staticmethod
    def rotation_y(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[cos_theta, 0, sin_theta, 0],
                      [0, 1, 0, 0],
                      [-sin_theta, 0, cos_theta, 0],
                      [0, 0, 0, 1]])

    @staticmethod
    def rotation_z(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[cos_theta, -sin_theta, 0, 0],
                      [sin_theta, cos_theta, 0, 0],
                      [0, 0, 1, 0],
                      [0, 0, 0, 1]])
    def __mul__(self, other):
        return Mat3D(np.dot(self.data, other.data))

    def transpose(self):
        return Mat3D(np.transpose(self.data))
    def inverse(self):
    # Calculate the inverse of the data using numpy's linalg.inv
        inv_data = np.linalg.inv(self.data)
        return Mat3D(inv_data) 


    def projection(f,aspect_ratio):
        nearZ = 1
        FarZ = 10
        zRange = nearZ - FarZ
        A = (-FarZ - nearZ) / zRange
        B = 2 * FarZ * nearZ /zRange
        return Mat3D([[f/aspect_ratio, 0, 0, 0],
                      [0, f, 0, 0],
                      [0, 0, A, B],
                      [0, 0, f, 0]])
    @classmethod
    def create_look_at(slf, eye, target, up):
        f = (target - eye).normalize()
        r = up.cross(f).normalize()
        u = f.cross(r).normalize()

        m = slf.identity()

        m[0][0] = r.x
        m[0][1] = r.y
        m[0][2] = r.z
        m[0][3] = 0

        m[1][0] = u.x
        m[1][1] = u.y
        m[1][2] = u.z
        m[1][3] = 0

        m[2][0] = -f.x
        m[2][1] = -f.y
        m[2][2] = -f.z
        m[2][3] = 0

        m[3][0] = 0
        m[3][1] = 0
        m[3][2] = 0
        m[3][3] = 1

        translation_matrix = slf.translation(-eye.x, -eye.y, -eye.z)
        return translation_matrix * m

